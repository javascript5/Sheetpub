
Responsive Icon Grid
=========
A responsive grid of anchors with icons and text. 

[article on Codrops](http://tympanus.net/codrops/?p=15657)

[demo](http://tympanus.net/Blueprints/ResponsiveIconGrid/)

[LICENSING & TERMS OF USE](http://tympanus.net/codrops/licensing/)